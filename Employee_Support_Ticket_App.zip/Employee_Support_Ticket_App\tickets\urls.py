from django.urls import path
from django.views.generic import RedirectView

from .views import (
    CommentCreateView,
    EmployeeAreaView,
    RoleHomeView,
    SupportStaffAreaView,
    TicketCreateView,
    TicketDetailView,
    TicketListView,
    TicketStatusUpdateView,
    TicketUpdateView,
)

urlpatterns = [
    path("", RedirectView.as_view(pattern_name="role_home", permanent=False), name="root"),
    path("home/", RoleHomeView.as_view(), name="role_home"),
    path("employee/area/", EmployeeAreaView.as_view(), name="employee_area"),
    path("support/area/", SupportStaffAreaView.as_view(), name="support_area"),
    path("tickets/", TicketListView.as_view(), name="ticket_list"),
    path("tickets/create/", TicketCreateView.as_view(), name="ticket_create"),
    path("tickets/<int:pk>/", TicketDetailView.as_view(), name="ticket_detail"),
    path("tickets/<int:pk>/edit/", TicketUpdateView.as_view(), name="ticket_update"),
    path(
        "tickets/<int:pk>/status/",
        TicketStatusUpdateView.as_view(),
        name="ticket_status_update",
    ),
    path(
        "tickets/<int:pk>/comments/",
        CommentCreateView.as_view(),
        name="ticket_comment_create",
    ),
]
