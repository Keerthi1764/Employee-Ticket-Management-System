from django.contrib.auth.models import Group
from django.core.management.base import BaseCommand

from tickets.permissions import EMPLOYEE_GROUP, SUPPORT_STAFF_GROUP


class Command(BaseCommand):
    help = "Create required application roles (Employee, Support Staff) if missing."

    def handle(self, *args, **options):
        roles = [EMPLOYEE_GROUP, SUPPORT_STAFF_GROUP]
        created = []
        existing = []

        for role in roles:
            _, was_created = Group.objects.get_or_create(name=role)
            if was_created:
                created.append(role)
            else:
                existing.append(role)

        if created:
            self.stdout.write(self.style.SUCCESS(f"Created roles: {', '.join(created)}"))
        if existing:
            self.stdout.write(f"Roles already present: {', '.join(existing)}")
        if not created and not existing:
            self.stdout.write("No roles processed.")
