from django import forms
from django.core.exceptions import ValidationError

from .models import Comment, Ticket


class BootstrapFormMixin:
    """Apply Bootstrap classes to form widgets."""

    def _apply_bootstrap(self):
        for name, field in self.fields.items():
            widget = field.widget
            existing = widget.attrs.get("class", "")
            if isinstance(widget, (forms.Select, forms.SelectMultiple)):
                base = "form-select"
            elif isinstance(widget, forms.CheckboxInput):
                base = "form-check-input"
            else:
                base = "form-control"
            classes = f"{existing} {base}".strip()
            if self.is_bound and self.errors.get(name):
                classes = f"{classes} is-invalid".strip()
            widget.attrs["class"] = classes


class TicketForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ["title", "description", "category", "priority"]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 5}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["title"].max_length = 100
        self.fields["title"].required = True
        self.fields["description"].required = True
        self.fields["category"].required = True
        self.fields["priority"].required = True
        self._apply_bootstrap()

    def clean_title(self):
        title = (self.cleaned_data.get("title") or "").strip()
        if not title:
            raise ValidationError("Title cannot be empty or contain only whitespace.")
        if len(title) > 100:
            raise ValidationError("Title cannot exceed 100 characters.")
        return title

    def clean_description(self):
        description = (self.cleaned_data.get("description") or "").strip()
        if not description:
            raise ValidationError(
                "Description cannot be empty or contain only whitespace."
            )
        return description


class TicketStatusForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ["status"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        current_status = self.instance.status if self.instance and self.instance.pk else None
        allowed = Ticket.get_selectable_statuses(current_status) if current_status else []
        choices = [("", "Select a status")] + [(s, s) for s in allowed]
        self.fields["status"].choices = choices
        self.fields["status"].required = True
        self._apply_bootstrap()
        if not allowed:
            self.fields["status"].widget.attrs["disabled"] = True

    def clean_status(self):
        new_status = self.cleaned_data.get("status")
        if not self.instance or not self.instance.pk:
            raise ValidationError("Invalid ticket.")
        current_status = self.instance.status
        if current_status == Ticket.Status.CLOSED:
            raise ValidationError("Closed tickets cannot be edited or reopened.")
        if new_status not in Ticket.get_selectable_statuses(current_status):
            raise ValidationError("Select a valid status.")
        return new_status


class CommentForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Comment
        fields = ["text"]
        widgets = {
            "text": forms.Textarea(
                attrs={"rows": 3, "placeholder": "Add a comment..."}
            ),
        }
        labels = {"text": "Comment"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["text"].required = True
        self._apply_bootstrap()

    def clean_text(self):
        text = (self.cleaned_data.get("text") or "").strip()
        if not text:
            raise ValidationError(
                "Comment text cannot be empty or contain only whitespace."
            )
        return text


class TicketFilterForm(BootstrapFormMixin, forms.Form):
    status = forms.ChoiceField(required=False)
    category = forms.ChoiceField(required=False)
    priority = forms.ChoiceField(required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["status"].choices = [("", "All Statuses")] + list(Ticket.Status.choices)
        self.fields["category"].choices = [("", "All Categories")] + list(Ticket.Category.choices)
        self.fields["priority"].choices = [("", "All Priorities")] + list(Ticket.Priority.choices)
        self._apply_bootstrap()
