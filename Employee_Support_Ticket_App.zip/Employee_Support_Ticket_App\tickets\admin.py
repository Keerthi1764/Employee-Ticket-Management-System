from django.contrib import admin

from .models import Comment, Ticket


@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "title",
        "category",
        "priority",
        "status",
        "created_by",
        "created_at",
        "updated_at",
    )
    list_filter = ("status", "category", "priority")
    search_fields = ("title", "description", "created_by__username")
    readonly_fields = ("created_by", "created_at", "updated_at")
    ordering = ("-created_at", "-id")

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ("id", "ticket", "author", "created_at", "short_text")
    search_fields = ("text", "author__username", "ticket__title")
    readonly_fields = ("ticket", "author", "text", "created_at")
    ordering = ("created_at", "id")

    def short_text(self, obj):
        return (obj.text[:50] + "...") if len(obj.text) > 50 else obj.text

    short_text.short_description = "Comment"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

