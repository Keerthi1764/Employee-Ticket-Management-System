from django import template

register = template.Library()


@register.filter
def can_edit_ticket(ticket, user):
    """Return True if the given user can edit the ticket (employee owner, not Closed)."""
    if not user or not getattr(user, "is_authenticated", False):
        return False
    if not ticket or not getattr(ticket, "pk", None):
        return False
    if ticket.status == "Closed":
        return False
    return ticket.created_by_id == user.id and user.groups.filter(name="Employee").exists()
