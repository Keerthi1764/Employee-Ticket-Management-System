import os
import secrets

from django.contrib.auth.models import Group, User
from django.core.management import call_command
from django.core.management.base import BaseCommand
from django.db import transaction

from tickets.models import Ticket
from tickets.permissions import EMPLOYEE_GROUP, SUPPORT_STAFF_GROUP


class Command(BaseCommand):
    help = "Create sample roles, users, and tickets for the Employee Support Ticket Management System (idempotent)."

    SAMPLE_TICKETS = [
        {
            "title": "Laptop not charging",
            "description": "My laptop does not charge when plugged into power.",
            "category": Ticket.Category.HARDWARE,
            "priority": Ticket.Priority.HIGH,
            "status": Ticket.Status.OPEN,
            "owner": "employee1",
        },
        {
            "title": "Need access to the shared project folder",
            "description": "I need access to the shared project folder for my team.",
            "category": Ticket.Category.ACCESS,
            "priority": Ticket.Priority.MEDIUM,
            "status": Ticket.Status.OPEN,
            "owner": "employee1",
        },
        {
            "title": "Request a second monitor",
            "description": "I would like to request a second monitor for my workstation.",
            "category": Ticket.Category.HARDWARE,
            "priority": Ticket.Priority.LOW,
            "status": Ticket.Status.CLOSED,
            "owner": "employee1",
        },
        {
            "title": "Cannot log in to VPN",
            "description": "VPN login fails with an authentication error.",
            "category": Ticket.Category.NETWORK,
            "priority": Ticket.Priority.HIGH,
            "status": Ticket.Status.IN_PROGRESS,
            "owner": "employee2",
        },
        {
            "title": "Excel keeps crashing on startup",
            "description": "Microsoft Excel crashes immediately after opening.",
            "category": Ticket.Category.SOFTWARE,
            "priority": Ticket.Priority.MEDIUM,
            "status": Ticket.Status.RESOLVED,
            "owner": "employee2",
        },
    ]

    @transaction.atomic
    def handle(self, *args, **options):
        call_command("setup_roles")

        employee_group = Group.objects.get(name=EMPLOYEE_GROUP)
        support_group = Group.objects.get(name=SUPPORT_STAFF_GROUP)

        users_spec = [
            ("employee1", employee_group, "SEED_EMPLOYEE1_PASSWORD"),
            ("employee2", employee_group, "SEED_EMPLOYEE2_PASSWORD"),
            ("support1", support_group, "SEED_SUPPORT1_PASSWORD"),
        ]

        created_credentials = []
        users = {}
        for username, group, env_key in users_spec:
            user, created = User.objects.get_or_create(username=username)
            if created:
                password = os.environ.get(env_key) or secrets.token_urlsafe(12)
                user.set_password(password)
                user.save()
                created_credentials.append((username, password, bool(os.environ.get(env_key))))
            # Ensure correct group membership (idempotent)
            user.groups.add(group)
            # Remove from the other app role group if accidentally present
            other_group = support_group if group == employee_group else employee_group
            if user.groups.filter(pk=other_group.pk).exists():
                user.groups.remove(other_group)
            users[username] = user

        created_tickets = 0
        existing_tickets = 0
        for spec in self.SAMPLE_TICKETS:
            owner = users[spec["owner"]]
            ticket, created = Ticket.objects.get_or_create(
                title=spec["title"],
                created_by=owner,
                defaults={
                    "description": spec["description"],
                    "category": spec["category"],
                    "priority": spec["priority"],
                    "status": spec["status"],
                },
            )
            if created:
                created_tickets += 1
            else:
                existing_tickets += 1
                # Ensure sample data remains consistent without violating transition rules unnecessarily.
                # Only safe non-status corrections for idempotency; status is part of the sample definition
                # and tickets are uniquely identified for seeding purposes.
                updates = {}
                for field in ("description", "category", "priority"):
                    if getattr(ticket, field) != spec[field]:
                        updates[field] = spec[field]
                # If status differs, respect model transition rules by not forcing illegal jumps here.
                # For a clean sample dataset, status should match when created by this command.
                if updates:
                    Ticket.objects.filter(pk=ticket.pk).update(**updates)

        if created_credentials:
            self.stdout.write(self.style.SUCCESS("Created sample users:"))
            for username, password, from_env in created_credentials:
                source = "from environment variable" if from_env else "generated (store securely)"
                self.stdout.write(f"  - {username}: {password} ({source})")
        else:
            self.stdout.write("Sample users already present (passwords unchanged).")

        self.stdout.write(
            self.style.SUCCESS(
                f"Sample tickets: {created_tickets} created, {existing_tickets} already present."
            )
        )
        self.stdout.write(self.style.SUCCESS("Seed completed successfully."))
