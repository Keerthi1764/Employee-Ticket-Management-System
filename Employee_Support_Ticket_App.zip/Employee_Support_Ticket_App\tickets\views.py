﻿from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.views import View
from django.views.generic import CreateView, DetailView, ListView, TemplateView, UpdateView

from .forms import CommentForm, TicketFilterForm, TicketForm, TicketStatusForm
from .models import Ticket
from .permissions import (
    EmployeeRequiredMixin,
    RoleAccessDeniedMixin,
    SupportStaffRequiredMixin,
    TicketViewPermissionMixin,
    can_change_status,
    can_comment_on_ticket,
    can_edit_ticket,
    can_view_ticket,
    get_user_role,
    is_employee,
    is_support_staff,
)


class RoleHomeView(LoginRequiredMixin, TemplateView):
    template_name = "tickets/role_home.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        context["user_role"] = get_user_role(user)
        context["is_employee"] = is_employee(user)
        context["is_support_staff"] = is_support_staff(user)
        context["has_recognized_role"] = context["user_role"] is not None
        # Dashboard counts
        if is_support_staff(user):
            context["visible_ticket_count"] = Ticket.objects.count()
        elif is_employee(user):
            context["visible_ticket_count"] = Ticket.objects.filter(created_by=user).count()
        else:
            context["visible_ticket_count"] = 0
        return context


class EmployeeAreaView(EmployeeRequiredMixin, TemplateView):
    """Employee dashboard/area."""

    template_name = "tickets/role_area.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["area_title"] = "Employee Dashboard"
        context["area_description"] = (
            "Create and track your support tickets. You can view and edit only your own tickets "
            "while they are not Closed."
        )
        context["show_ticket_actions"] = True
        context["is_employee_area"] = True
        return context


class SupportStaffAreaView(SupportStaffRequiredMixin, TemplateView):
    """Support staff dashboard/area."""

    template_name = "tickets/role_area.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["area_title"] = "Support Staff Dashboard"
        context["area_description"] = (
            "View and manage all employee support tickets, monitor statuses, and assist with resolutions."
        )
        context["show_ticket_actions"] = True
        context["is_support_area"] = True
        return context


class TicketListView(LoginRequiredMixin, ListView):
    model = Ticket
    template_name = "tickets/ticket_list.html"
    context_object_name = "tickets"

    def get_queryset(self):
        user = self.request.user
        if is_support_staff(user):
            qs = Ticket.objects.all()
        elif is_employee(user):
            qs = Ticket.objects.filter(created_by=user)
        else:
            qs = Ticket.objects.none()

        self.filter_form = TicketFilterForm(self.request.GET or None)
        if is_support_staff(user) and self.filter_form.is_valid():
            status = self.filter_form.cleaned_data.get("status")
            category = self.filter_form.cleaned_data.get("category")
            priority = self.filter_form.cleaned_data.get("priority")
            if status:
                qs = qs.filter(status=status)
            if category:
                qs = qs.filter(category=category)
            if priority:
                qs = qs.filter(priority=priority)

        return qs.select_related("created_by").order_by("-created_at", "-id")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        context["is_employee"] = is_employee(user)
        context["is_support_staff"] = is_support_staff(user)
        context["page_title"] = "All Tickets" if is_support_staff(user) else "My Tickets"
        context["filter_form"] = getattr(self, "filter_form", TicketFilterForm())
        context["filters_active"] = bool(
            is_support_staff(user)
            and self.filter_form.is_valid()
            and any(self.filter_form.cleaned_data.get(k) for k in ["status", "category", "priority"])
        )
        return context


class TicketCreateView(EmployeeRequiredMixin, CreateView):
    model = Ticket
    form_class = TicketForm
    template_name = "tickets/ticket_form.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["form_title"] = "Create Ticket"
        context["submit_label"] = "Create Ticket"
        context["is_create"] = True
        return context

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        # Defaults are enforced by model (status Open, priority Medium) unless overridden by form choices.
        response = super().form_valid(form)
        messages.success(self.request, "Ticket created successfully.")
        return response

    def get_success_url(self):
        return reverse("ticket_detail", kwargs={"pk": self.object.pk})


class TicketDetailView(TicketViewPermissionMixin, DetailView):
    model = Ticket
    template_name = "tickets/ticket_detail.html"
    context_object_name = "ticket"

    def get_queryset(self):
        return Ticket.objects.select_related("created_by").prefetch_related(
            "comments__author"
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        ticket = self.object
        user = self.request.user
        context["can_edit_ticket"] = can_edit_ticket(user, ticket)
        context["is_support_staff_user"] = is_support_staff(user)
        context["is_employee_user"] = is_employee(user)
        context["can_change_status"] = can_change_status(user, ticket)
        context["can_comment"] = can_comment_on_ticket(user, ticket)
        context["comments"] = ticket.comments.select_related("author").all()

        if context["can_change_status"] and ticket.status != Ticket.Status.CLOSED:
            context["status_form"] = kwargs.get("status_form") or TicketStatusForm(instance=ticket)
        else:
            context["status_form"] = None

        if context["can_comment"]:
            context["comment_form"] = kwargs.get("comment_form") or CommentForm()
        else:
            context["comment_form"] = None
        return context


class TicketUpdateView(LoginRequiredMixin, UpdateView):
    model = Ticket
    form_class = TicketForm
    template_name = "tickets/ticket_form.html"

    def get_queryset(self):
        # Employees can only access their own tickets for editing attempts.
        user = self.request.user
        if is_employee(user):
            return Ticket.objects.filter(created_by=user)
        # Support staff (or others) should be denied by permission checks, but limit queryset.
        return Ticket.objects.all()

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return super().dispatch(request, *args, **kwargs)
        self.object = self.get_object()
        if not is_employee(request.user):
            messages.error(request, "Only employees can edit ticket details.")
            return redirect("ticket_detail", pk=self.object.pk)
        if self.object.created_by_id != request.user.id:
            messages.error(request, "You do not have permission to edit this ticket.")
            return redirect("ticket_list")
        if self.object.status == Ticket.Status.CLOSED:
            messages.error(
                request,
                "Closed tickets cannot be edited.",
            )
            return redirect("ticket_detail", pk=self.object.pk)
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["form_title"] = f"Edit Ticket #{self.object.pk}"
        context["submit_label"] = "Save Changes"
        context["is_create"] = False
        return context

    def form_valid(self, form):
        # Ensure status/created_by/timestamps are not user-editable; only allowed fields are in form.
        response = super().form_valid(form)
        messages.success(self.request, "Ticket updated successfully.")
        return response

    def get_success_url(self):
        return reverse("ticket_detail", kwargs={"pk": self.object.pk})




class TicketStatusUpdateView(SupportStaffRequiredMixin, LoginRequiredMixin, UpdateView):
    model = Ticket
    form_class = TicketStatusForm
    template_name = "tickets/ticket_detail.html"
    http_method_names = ["post"]
    permission_denied_message = "Only support staff can change ticket status."
    permission_denied_redirect = "ticket_list"

    def get_queryset(self):
        return Ticket.objects.select_related("created_by")

    def form_valid(self, form):
        ticket = form.save()
        messages.success(
            self.request,
            f"Ticket status updated to {ticket.status}.",
        )
        return redirect("ticket_detail", pk=ticket.pk)

    def form_invalid(self, form):
        error_messages = []
        for errs in form.errors.values():
            for err in errs:
                error_messages.append(err)
        if not error_messages:
            error_messages.append("Invalid status update request.")
        for msg in error_messages:
            messages.error(self.request, msg)
        return redirect("ticket_detail", pk=self.get_object().pk)

class CommentCreateView(LoginRequiredMixin, View):
    http_method_names = ["post"]

    def post(self, request, pk, *args, **kwargs):
        ticket = get_object_or_404(Ticket.objects.select_related("created_by"), pk=pk)
        if not can_comment_on_ticket(request.user, ticket):
            messages.error(request, "You do not have permission to comment on this ticket.")
            return redirect("ticket_list")

        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.ticket = ticket
            comment.author = request.user
            comment.save()  # Comment save must not modify ticket.updated_at
            messages.success(request, "Comment added successfully.")
        else:
            for field_errors in form.errors.values():
                for error in field_errors:
                    messages.error(request, error)
            if not form.errors:
                messages.error(request, "Unable to add comment. Please try again.")
        return redirect("ticket_detail", pk=ticket.pk)
