from django.contrib.auth.models import Group, User
from django.test import TestCase
from django.urls import reverse

from .models import Comment, Ticket
from .permissions import EMPLOYEE_GROUP, SUPPORT_STAFF_GROUP


class AuthenticationAndRolesTests(TestCase):
    def setUp(self):
        self.employee_group, _ = Group.objects.get_or_create(name=EMPLOYEE_GROUP)
        self.support_group, _ = Group.objects.get_or_create(name=SUPPORT_STAFF_GROUP)

        self.employee_user = User.objects.create_user(username="employee_user", password="Pass12345!")
        self.employee_user.groups.add(self.employee_group)

        self.support_user = User.objects.create_user(username="support_user", password="Pass12345!")
        self.support_user.groups.add(self.support_group)

        self.no_role_user = User.objects.create_user(username="norole_user", password="Pass12345!")

    def test_login_page_renders(self):
        response = self.client.get(reverse("login"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Login")
        self.assertContains(response, 'name="username"')
        self.assertContains(response, 'name="password"')

    def test_invalid_login_shows_error_and_does_not_authenticate(self):
        response = self.client.post(
            reverse("login"),
            {"username": "employee_user", "password": "wrong-password"},
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Please enter a correct username and password")
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_login_validation_requires_username_and_password(self):
        response = self.client.post(reverse("login"), {"username": "", "password": ""})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "This field is required")
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_unauthenticated_user_redirected_from_protected_pages(self):
        protected_urls = [reverse("role_home"), reverse("employee_area"), reverse("support_area")]
        for url in protected_urls:
            with self.subTest(url=url):
                response = self.client.get(url)
                self.assertEqual(response.status_code, 302)
                self.assertIn(reverse("login"), response.url)

    def test_root_redirects_to_role_home_then_login_when_anonymous(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse("role_home"))
        response = self.client.get(response.url)
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response.url)

    def test_employee_login_can_access_employee_area(self):
        login_response = self.client.post(
            reverse("login"),
            {"username": "employee_user", "password": "Pass12345!"},
            follow=True,
        )
        self.assertEqual(login_response.status_code, 200)
        self.assertTrue(login_response.context["user"].is_authenticated)
        response = self.client.get(reverse("employee_area"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Employee Dashboard")

    def test_employee_cannot_access_support_area(self):
        self.client.login(username="employee_user", password="Pass12345!")
        response = self.client.get(reverse("support_area"), follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.request["PATH_INFO"], reverse("role_home"))
        self.assertContains(response, "Support staff access required.")

    def test_support_staff_can_access_support_area(self):
        self.client.login(username="support_user", password="Pass12345!")
        response = self.client.get(reverse("support_area"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Support Staff Dashboard")

    def test_support_staff_cannot_access_employee_area(self):
        self.client.login(username="support_user", password="Pass12345!")
        response = self.client.get(reverse("employee_area"), follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.request["PATH_INFO"], reverse("role_home"))
        self.assertContains(response, "Employee access required.")

    def test_authenticated_user_without_role_sees_warning_on_home(self):
        self.client.login(username="norole_user", password="Pass12345!")
        response = self.client.get(reverse("role_home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "No recognized application role assigned")

    def test_logout_ends_session_and_protects_pages(self):
        self.client.login(username="employee_user", password="Pass12345!")
        self.assertIn("_auth_user_id", self.client.session)
        response = self.client.post(reverse("logout"), follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)
        protected_response = self.client.get(reverse("role_home"))
        self.assertEqual(protected_response.status_code, 302)
        self.assertIn(reverse("login"), protected_response.url)


class RoleSetupCommandTests(TestCase):
    def test_setup_roles_command_creates_required_groups(self):
        from django.core.management import call_command

        Group.objects.all().delete()
        call_command("setup_roles")
        self.assertTrue(Group.objects.filter(name=EMPLOYEE_GROUP).exists())
        self.assertTrue(Group.objects.filter(name=SUPPORT_STAFF_GROUP).exists())
        # idempotent
        call_command("setup_roles")
        self.assertEqual(Group.objects.filter(name__in=[EMPLOYEE_GROUP, SUPPORT_STAFF_GROUP]).count(), 2)


class TicketCoreWorkflowTests(TestCase):
    def setUp(self):
        self.employee_group, _ = Group.objects.get_or_create(name=EMPLOYEE_GROUP)
        self.support_group, _ = Group.objects.get_or_create(name=SUPPORT_STAFF_GROUP)

        self.employee1 = User.objects.create_user(username="employee1", password="Pass12345!")
        self.employee1.groups.add(self.employee_group)
        self.employee2 = User.objects.create_user(username="employee2", password="Pass12345!")
        self.employee2.groups.add(self.employee_group)
        self.support = User.objects.create_user(username="support1", password="Pass12345!")
        self.support.groups.add(self.support_group)

        self.ticket_e1_open = Ticket.objects.create(
            title="E1 Open Ticket",
            description="Open description",
            category=Ticket.Category.HARDWARE,
            priority=Ticket.Priority.HIGH,
            status=Ticket.Status.OPEN,
            created_by=self.employee1,
        )
        self.ticket_e2_open = Ticket.objects.create(
            title="E2 Open Ticket",
            description="Other employee ticket",
            category=Ticket.Category.SOFTWARE,
            priority=Ticket.Priority.MEDIUM,
            status=Ticket.Status.OPEN,
            created_by=self.employee2,
        )
        self.ticket_e1_closed = Ticket.objects.create(
            title="E1 Closed Ticket",
            description="Closed description",
            category=Ticket.Category.ACCESS,
            priority=Ticket.Priority.LOW,
            status=Ticket.Status.CLOSED,
            created_by=self.employee1,
        )

    def test_employee_can_create_ticket_with_defaults(self):
        self.client.login(username="employee1", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_create"),
            {
                "title": "Printer issue",
                "description": "Printer not working in office.",
                "category": Ticket.Category.HARDWARE,
                "priority": Ticket.Priority.MEDIUM,
            },
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        ticket = Ticket.objects.get(title="Printer issue")
        self.assertEqual(ticket.created_by, self.employee1)
        self.assertEqual(ticket.status, Ticket.Status.OPEN)
        self.assertEqual(ticket.priority, Ticket.Priority.MEDIUM)
        self.assertContains(response, "Ticket created successfully.")

    def test_ticket_creation_required_field_validation(self):
        self.client.login(username="employee1", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_create"),
            {
                "title": "   ",
                "description": "",
                "category": "",
                "priority": "",
            },
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Ticket.objects.filter(created_by=self.employee1).count(), 2)  # existing in setUp
        form = response.context["form"]
        self.assertIn("title", form.errors)
        self.assertIn("description", form.errors)
        self.assertIn("category", form.errors)
        self.assertIn("priority", form.errors)

    def test_employee_sees_only_own_tickets_in_list(self):
        self.client.login(username="employee1", password="Pass12345!")
        response = self.client.get(reverse("ticket_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.ticket_e1_open.title)
        self.assertContains(response, self.ticket_e1_closed.title)
        self.assertNotContains(response, self.ticket_e2_open.title)

    def test_support_staff_sees_all_tickets_in_list(self):
        self.client.login(username="support1", password="Pass12345!")
        response = self.client.get(reverse("ticket_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.ticket_e1_open.title)
        self.assertContains(response, self.ticket_e1_closed.title)
        self.assertContains(response, self.ticket_e2_open.title)

    def test_employee_can_view_own_ticket_detail_but_not_others(self):
        self.client.login(username="employee1", password="Pass12345!")
        own_response = self.client.get(reverse("ticket_detail", args=[self.ticket_e1_open.pk]))
        self.assertEqual(own_response.status_code, 200)
        self.assertContains(own_response, self.ticket_e1_open.description)

        other_response = self.client.get(reverse("ticket_detail", args=[self.ticket_e2_open.pk]))
        # redirected by permission mixin with error message
        self.assertEqual(other_response.status_code, 302)
        self.assertEqual(other_response.url, reverse("ticket_list"))

    def test_support_staff_can_view_any_ticket_detail(self):
        self.client.login(username="support1", password="Pass12345!")
        response = self.client.get(reverse("ticket_detail", args=[self.ticket_e2_open.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.ticket_e2_open.title)

    def test_employee_can_edit_own_open_ticket(self):
        self.client.login(username="employee1", password="Pass12345!")
        url = reverse("ticket_update", args=[self.ticket_e1_open.pk])
        response = self.client.post(
            url,
            {
                "title": "Updated E1 Open Ticket",
                "description": "Updated description",
                "category": Ticket.Category.NETWORK,
                "priority": Ticket.Priority.LOW,
            },
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.ticket_e1_open.refresh_from_db()
        self.assertEqual(self.ticket_e1_open.title, "Updated E1 Open Ticket")
        self.assertEqual(self.ticket_e1_open.category, Ticket.Category.NETWORK)
        self.assertEqual(self.ticket_e1_open.priority, Ticket.Priority.LOW)
        self.assertEqual(self.ticket_e1_open.status, Ticket.Status.OPEN)
        self.assertContains(response, "Ticket updated successfully.")

    def test_employee_can_edit_own_ticket_that_is_not_closed(self):
        self.ticket_e1_open.status = Ticket.Status.IN_PROGRESS
        self.ticket_e1_open.save(update_fields=["status"])
        self.client.login(username="employee1", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_update", args=[self.ticket_e1_open.pk]),
            {
                "title": "Updated In Progress Ticket",
                "description": "Updated while in progress",
                "category": Ticket.Category.ACCESS,
                "priority": Ticket.Priority.HIGH,
            },
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.ticket_e1_open.refresh_from_db()
        self.assertEqual(self.ticket_e1_open.title, "Updated In Progress Ticket")
        self.assertEqual(self.ticket_e1_open.status, Ticket.Status.IN_PROGRESS)

    def test_employee_cannot_edit_others_ticket(self):
        self.client.login(username="employee1", password="Pass12345!")
        url = reverse("ticket_update", args=[self.ticket_e2_open.pk])
        response = self.client.get(url)
        # queryset/dispatch should prevent access
        self.assertIn(response.status_code, [302, 404])

    def test_employee_cannot_edit_closed_ticket(self):
        self.client.login(username="employee1", password="Pass12345!")
        url = reverse("ticket_update", args=[self.ticket_e1_closed.pk])
        response = self.client.get(url, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.request["PATH_INFO"], reverse("ticket_detail", args=[self.ticket_e1_closed.pk]))
        self.assertContains(response, "Closed tickets cannot be edited.")

    def test_unauthenticated_users_redirected_from_ticket_pages(self):
        urls = [
            reverse("ticket_list"),
            reverse("ticket_create"),
            reverse("ticket_detail", args=[self.ticket_e1_open.pk]),
            reverse("ticket_update", args=[self.ticket_e1_open.pk]),
        ]
        for url in urls:
            with self.subTest(url=url):
                response = self.client.get(url)
                self.assertEqual(response.status_code, 302)
                self.assertIn(reverse("login"), response.url)

    def test_support_staff_cannot_create_ticket_via_ui(self):
        self.client.login(username="support1", password="Pass12345!")
        response = self.client.get(reverse("ticket_create"), follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.request["PATH_INFO"], reverse("role_home"))
        self.assertContains(response, "Employee access required.")


class StatusManagementAndFilteringTests(TestCase):
    def setUp(self):
        self.employee_group, _ = Group.objects.get_or_create(name=EMPLOYEE_GROUP)
        self.support_group, _ = Group.objects.get_or_create(name=SUPPORT_STAFF_GROUP)

        self.employee = User.objects.create_user(username="emp_status", password="Pass12345!")
        self.employee.groups.add(self.employee_group)
        self.employee2 = User.objects.create_user(username="emp_status2", password="Pass12345!")
        self.employee2.groups.add(self.employee_group)
        self.support = User.objects.create_user(username="sup_status", password="Pass12345!")
        self.support.groups.add(self.support_group)

        self.open_ticket = Ticket.objects.create(
            title="Open Ticket",
            description="Open",
            category=Ticket.Category.HARDWARE,
            priority=Ticket.Priority.HIGH,
            status=Ticket.Status.OPEN,
            created_by=self.employee,
        )
        self.in_progress_ticket = Ticket.objects.create(
            title="In Progress Ticket",
            description="In progress",
            category=Ticket.Category.SOFTWARE,
            priority=Ticket.Priority.MEDIUM,
            status=Ticket.Status.IN_PROGRESS,
            created_by=self.employee,
        )
        self.resolved_ticket = Ticket.objects.create(
            title="Resolved Ticket",
            description="Resolved",
            category=Ticket.Category.NETWORK,
            priority=Ticket.Priority.LOW,
            status=Ticket.Status.RESOLVED,
            created_by=self.employee,
        )
        self.closed_ticket = Ticket.objects.create(
            title="Closed Ticket",
            description="Closed",
            category=Ticket.Category.ACCESS,
            priority=Ticket.Priority.MEDIUM,
            status=Ticket.Status.CLOSED,
            created_by=self.employee,
        )
        # Extra tickets for filtering
        self.filter_ticket = Ticket.objects.create(
            title="Filter Match",
            description="Filter",
            category=Ticket.Category.SOFTWARE,
            priority=Ticket.Priority.HIGH,
            status=Ticket.Status.OPEN,
            created_by=self.employee2,
        )

    def test_support_staff_can_set_any_status_and_updated_at_changes(self):
        self.client.login(username="sup_status", password="Pass12345!")
        ticket = self.open_ticket
        old_updated = ticket.updated_at

        response = self.client.post(
            reverse("ticket_status_update", args=[ticket.pk]),
            {"status": Ticket.Status.RESOLVED},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        ticket.refresh_from_db()
        self.assertEqual(ticket.status, Ticket.Status.RESOLVED)
        self.assertGreater(ticket.updated_at, old_updated)
        self.assertContains(response, "Ticket status updated to Resolved.")

        old_updated = ticket.updated_at
        response = self.client.post(
            reverse("ticket_status_update", args=[ticket.pk]),
            {"status": Ticket.Status.IN_PROGRESS},
            follow=True,
        )
        ticket.refresh_from_db()
        self.assertEqual(ticket.status, Ticket.Status.IN_PROGRESS)
        self.assertGreater(ticket.updated_at, old_updated)

        old_updated = ticket.updated_at
        response = self.client.post(
            reverse("ticket_status_update", args=[ticket.pk]),
            {"status": Ticket.Status.CLOSED},
            follow=True,
        )
        ticket.refresh_from_db()
        self.assertEqual(ticket.status, Ticket.Status.CLOSED)
        self.assertGreater(ticket.updated_at, old_updated)

    def test_employee_cannot_change_ticket_status(self):
        self.client.login(username="emp_status", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_status_update", args=[self.open_ticket.pk]),
            {"status": Ticket.Status.IN_PROGRESS},
            follow=True,
        )
        self.open_ticket.refresh_from_db()
        self.assertEqual(self.open_ticket.status, Ticket.Status.OPEN)
        self.assertContains(response, "Only support staff can change ticket status.")

    def test_invalid_status_updates_rejected(self):
        self.client.login(username="sup_status", password="Pass12345!")
        # Same status is not a valid change
        response = self.client.post(
            reverse("ticket_status_update", args=[self.open_ticket.pk]),
            {"status": Ticket.Status.OPEN},
            follow=True,
        )
        self.open_ticket.refresh_from_db()
        self.assertEqual(self.open_ticket.status, Ticket.Status.OPEN)
        self.assertContains(response, "Select a valid choice.")

        # Empty status is rejected
        response = self.client.post(
            reverse("ticket_status_update", args=[self.in_progress_ticket.pk]),
            {"status": ""},
            follow=True,
        )
        self.in_progress_ticket.refresh_from_db()
        self.assertEqual(self.in_progress_ticket.status, Ticket.Status.IN_PROGRESS)
        self.assertContains(response, "This field is required.")

    def test_closed_ticket_cannot_be_reopened_or_changed(self):
        self.client.login(username="sup_status", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_status_update", args=[self.closed_ticket.pk]),
            {"status": Ticket.Status.OPEN},
            follow=True,
        )
        self.closed_ticket.refresh_from_db()
        self.assertEqual(self.closed_ticket.status, Ticket.Status.CLOSED)
        self.assertContains(response, "Select a valid choice.")

    def test_support_staff_can_filter_tickets_by_status_category_priority(self):
        self.client.login(username="sup_status", password="Pass12345!")
        # by status
        response = self.client.get(reverse("ticket_list"), {"status": Ticket.Status.OPEN})
        self.assertContains(response, self.open_ticket.title)
        self.assertContains(response, self.filter_ticket.title)
        self.assertNotContains(response, self.closed_ticket.title)

        # by category
        response = self.client.get(reverse("ticket_list"), {"category": Ticket.Category.SOFTWARE})
        self.assertContains(response, self.in_progress_ticket.title)
        self.assertContains(response, self.filter_ticket.title)
        self.assertNotContains(response, self.open_ticket.title)

        # by priority
        response = self.client.get(reverse("ticket_list"), {"priority": Ticket.Priority.HIGH})
        self.assertContains(response, self.open_ticket.title)
        self.assertContains(response, self.filter_ticket.title)
        self.assertNotContains(response, self.resolved_ticket.title)

        # combined filters
        response = self.client.get(
            reverse("ticket_list"),
            {
                "status": Ticket.Status.OPEN,
                "category": Ticket.Category.SOFTWARE,
                "priority": Ticket.Priority.HIGH,
            },
        )
        self.assertContains(response, self.filter_ticket.title)
        self.assertNotContains(response, self.open_ticket.title)
        self.assertNotContains(response, self.in_progress_ticket.title)

    def test_employee_ticket_list_not_filterable_by_support_filters(self):
        self.client.login(username="emp_status", password="Pass12345!")
        # employee sees only own tickets anyway; filter params should not leak others
        response = self.client.get(
            reverse("ticket_list"),
            {"status": Ticket.Status.OPEN, "category": Ticket.Category.SOFTWARE},
        )
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, self.filter_ticket.title)  # owned by employee2
        # own matching open ticket (hardware) should not appear because category filter ignored? our view only applies filters for support
        self.assertContains(response, self.open_ticket.title)

    def test_support_staff_cannot_edit_ticket_fields_only_status(self):
        self.client.login(username="sup_status", password="Pass12345!")
        # No edit form for support; attempting employee edit route should be denied by view logic
        response = self.client.get(reverse("ticket_update", args=[self.open_ticket.pk]), follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.request["PATH_INFO"], reverse("ticket_detail", args=[self.open_ticket.pk]))
        self.assertContains(response, "Only employees can edit ticket details.")


class CommentWorkflowTests(TestCase):
    def setUp(self):
        self.employee_group, _ = Group.objects.get_or_create(name=EMPLOYEE_GROUP)
        self.support_group, _ = Group.objects.get_or_create(name=SUPPORT_STAFF_GROUP)

        self.employee1 = User.objects.create_user(username="emp_c1", password="Pass12345!")
        self.employee1.groups.add(self.employee_group)
        self.employee2 = User.objects.create_user(username="emp_c2", password="Pass12345!")
        self.employee2.groups.add(self.employee_group)
        self.support = User.objects.create_user(username="sup_c", password="Pass12345!")
        self.support.groups.add(self.support_group)

        self.ticket_e1_open = Ticket.objects.create(
            title="E1 Open",
            description="Desc",
            category=Ticket.Category.HARDWARE,
            priority=Ticket.Priority.MEDIUM,
            status=Ticket.Status.OPEN,
            created_by=self.employee1,
        )
        self.ticket_e2_open = Ticket.objects.create(
            title="E2 Open",
            description="Desc",
            category=Ticket.Category.SOFTWARE,
            priority=Ticket.Priority.MEDIUM,
            status=Ticket.Status.OPEN,
            created_by=self.employee2,
        )
        self.ticket_e1_closed = Ticket.objects.create(
            title="E1 Closed",
            description="Desc",
            category=Ticket.Category.ACCESS,
            priority=Ticket.Priority.LOW,
            status=Ticket.Status.CLOSED,
            created_by=self.employee1,
        )

    def test_employee_and_support_can_add_comment_on_authorized_ticket(self):
        # Employee on own ticket
        self.client.login(username="emp_c1", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_comment_create", args=[self.ticket_e1_open.pk]),
            {"text": "Employee comment"},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(Comment.objects.filter(ticket=self.ticket_e1_open, text="Employee comment", author=self.employee1).exists())
        self.assertContains(response, "Comment added successfully.")

        # Support on any ticket
        self.client.login(username="sup_c", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_comment_create", args=[self.ticket_e1_open.pk]),
            {"text": "Support comment"},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(Comment.objects.filter(ticket=self.ticket_e1_open, text="Support comment", author=self.support).exists())

    def test_can_comment_on_closed_ticket_if_authorized(self):
        self.client.login(username="emp_c1", password="Pass12345!")
        old_updated = Ticket.objects.get(pk=self.ticket_e1_closed.pk).updated_at
        response = self.client.post(
            reverse("ticket_comment_create", args=[self.ticket_e1_closed.pk]),
            {"text": "Comment on closed ticket"},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(Comment.objects.filter(ticket=self.ticket_e1_closed, text="Comment on closed ticket").exists())
        self.ticket_e1_closed.refresh_from_db()
        self.assertEqual(self.ticket_e1_closed.status, Ticket.Status.CLOSED)

        self.client.login(username="sup_c", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_comment_create", args=[self.ticket_e1_closed.pk]),
            {"text": "Support comment on closed ticket"},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(Comment.objects.filter(ticket=self.ticket_e1_closed, text="Support comment on closed ticket").exists())

    def test_comment_does_not_modify_ticket_updated_at(self):
        old_updated = Ticket.objects.get(pk=self.ticket_e1_open.pk).updated_at
        self.client.login(username="emp_c1", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_comment_create", args=[self.ticket_e1_open.pk]),
            {"text": "Non-updating comment"},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.ticket_e1_open.refresh_from_db()
        self.assertEqual(self.ticket_e1_open.updated_at, old_updated)

    def test_empty_or_whitespace_comment_rejected(self):
        self.client.login(username="emp_c1", password="Pass12345!")
        for payload in [{"text": ""}, {"text": "   "}]:
            with self.subTest(payload=payload):
                response = self.client.post(
                    reverse("ticket_comment_create", args=[self.ticket_e1_open.pk]),
                    payload,
                    follow=True,
                )
                self.assertEqual(response.status_code, 200)
                self.assertEqual(Comment.objects.filter(ticket=self.ticket_e1_open).count(), 0)
                self.assertContains(response, "cannot be empty")

    def test_employee_cannot_comment_on_others_ticket(self):
        self.client.login(username="emp_c1", password="Pass12345!")
        response = self.client.post(
            reverse("ticket_comment_create", args=[self.ticket_e2_open.pk]),
            {"text": "Should not work"},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Comment.objects.filter(ticket=self.ticket_e2_open).count(), 0)
        self.assertContains(response, "You do not have permission to comment on this ticket.")

    def test_comments_display_in_chronological_order(self):
        c1 = Comment.objects.create(ticket=self.ticket_e1_open, author=self.employee1, text="First")
        c2 = Comment.objects.create(ticket=self.ticket_e1_open, author=self.support, text="Second")
        self.client.login(username="emp_c1", password="Pass12345!")
        response = self.client.get(reverse("ticket_detail", args=[self.ticket_e1_open.pk]))
        self.assertEqual(response.status_code, 200)
        content = response.content.decode()
        self.assertLess(content.index("First"), content.index("Second"))
        self.assertContains(response, "commented")
        self.assertContains(response, c1.created_at.strftime("%Y-%m-%d"))

class SampleDataAndExtraSecurityTests(TestCase):
    def test_seed_command_creates_required_data_and_is_idempotent(self):
        from django.core.management import call_command

        # First run
        call_command("seed")

        self.assertTrue(Group.objects.filter(name=EMPLOYEE_GROUP).exists())
        self.assertTrue(Group.objects.filter(name=SUPPORT_STAFF_GROUP).exists())

        employee1 = User.objects.get(username="employee1")
        employee2 = User.objects.get(username="employee2")
        support1 = User.objects.get(username="support1")
        self.assertTrue(employee1.groups.filter(name=EMPLOYEE_GROUP).exists())
        self.assertTrue(employee2.groups.filter(name=EMPLOYEE_GROUP).exists())
        self.assertTrue(support1.groups.filter(name=SUPPORT_STAFF_GROUP).exists())

        expected = [
            ("Laptop not charging", "employee1", Ticket.Category.HARDWARE, Ticket.Priority.HIGH, Ticket.Status.OPEN),
            ("Need access to the shared project folder", "employee1", Ticket.Category.ACCESS, Ticket.Priority.MEDIUM, Ticket.Status.OPEN),
            ("Request a second monitor", "employee1", Ticket.Category.HARDWARE, Ticket.Priority.LOW, Ticket.Status.CLOSED),
            ("Cannot log in to VPN", "employee2", Ticket.Category.NETWORK, Ticket.Priority.HIGH, Ticket.Status.IN_PROGRESS),
            ("Excel keeps crashing on startup", "employee2", Ticket.Category.SOFTWARE, Ticket.Priority.MEDIUM, Ticket.Status.RESOLVED),
        ]
        for title, owner_username, category, priority, status in expected:
            ticket = Ticket.objects.get(title=title, created_by__username=owner_username)
            self.assertEqual(ticket.category, category)
            self.assertEqual(ticket.priority, priority)
            self.assertEqual(ticket.status, status)

        counts = {
            "users": User.objects.filter(username__in=["employee1", "employee2", "support1"]).count(),
            "tickets": Ticket.objects.count(),
            "groups": Group.objects.filter(name__in=[EMPLOYEE_GROUP, SUPPORT_STAFF_GROUP]).count(),
        }

        # Second run (idempotent)
        call_command("seed")
        self.assertEqual(User.objects.filter(username__in=["employee1", "employee2", "support1"]).count(), counts["users"])
        self.assertEqual(Ticket.objects.count(), counts["tickets"])
        self.assertEqual(Group.objects.filter(name__in=[EMPLOYEE_GROUP, SUPPORT_STAFF_GROUP]).count(), counts["groups"])
        # Verify key records still correct
        self.assertEqual(Ticket.objects.get(title="Laptop not charging", created_by__username="employee1").status, Ticket.Status.OPEN)
        self.assertEqual(Ticket.objects.get(title="Request a second monitor", created_by__username="employee1").status, Ticket.Status.CLOSED)

    def test_unauthenticated_post_requests_redirect_to_login(self):
        employee_group, _ = Group.objects.get_or_create(name=EMPLOYEE_GROUP)
        employee = User.objects.create_user(username="anon_emp", password="Pass12345!")
        employee.groups.add(employee_group)
        ticket = Ticket.objects.create(
            title="Anon test",
            description="Desc",
            category=Ticket.Category.OTHER,
            priority=Ticket.Priority.MEDIUM,
            status=Ticket.Status.OPEN,
            created_by=employee,
        )
        protected_posts = [
            (reverse("ticket_status_update", args=[ticket.pk]), {"status": Ticket.Status.IN_PROGRESS}),
            (reverse("ticket_comment_create", args=[ticket.pk]), {"text": "Hello"}),
        ]
        for url, data in protected_posts:
            with self.subTest(url=url):
                response = self.client.post(url, data)
                self.assertEqual(response.status_code, 302)
                self.assertIn(reverse("login"), response.url)
