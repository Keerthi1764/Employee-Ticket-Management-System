from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import redirect

EMPLOYEE_GROUP = "Employee"
SUPPORT_STAFF_GROUP = "Support Staff"


def is_employee(user):
    return user.is_authenticated and user.groups.filter(name=EMPLOYEE_GROUP).exists()


def is_support_staff(user):
    return user.is_authenticated and user.groups.filter(name=SUPPORT_STAFF_GROUP).exists()


def get_user_role(user):
    if is_support_staff(user):
        return SUPPORT_STAFF_GROUP
    if is_employee(user):
        return EMPLOYEE_GROUP
    return None


def can_view_ticket(user, ticket):
    if not user.is_authenticated or ticket is None:
        return False
    if is_support_staff(user):
        return True
    return is_employee(user) and ticket.created_by_id == user.id


def can_edit_ticket(user, ticket):
    if not can_view_ticket(user, ticket):
        return False
    return (
        is_employee(user)
        and ticket.created_by_id == user.id
        and getattr(ticket, "status", None) == "Open"
    )


def can_change_status(user, ticket):
    return bool(user.is_authenticated and is_support_staff(user) and ticket is not None)


def can_comment_on_ticket(user, ticket):
    return can_view_ticket(user, ticket)


class RoleAccessDeniedMixin(UserPassesTestMixin):
    """Base mixin for role-based server-side access control."""

    permission_denied_message = "You do not have permission to access this page."
    permission_denied_redirect = "role_home"

    def handle_no_permission(self):
        if not self.request.user.is_authenticated:
            return super().handle_no_permission()
        messages.error(self.request, self.permission_denied_message)
        return redirect(self.permission_denied_redirect)


class EmployeeRequiredMixin(LoginRequiredMixin, RoleAccessDeniedMixin):
    permission_denied_message = "Employee access required."

    def test_func(self):
        return is_employee(self.request.user)


class SupportStaffRequiredMixin(LoginRequiredMixin, RoleAccessDeniedMixin):
    permission_denied_message = "Support staff access required."

    def test_func(self):
        return is_support_staff(self.request.user)


class TicketViewPermissionMixin(LoginRequiredMixin, RoleAccessDeniedMixin):
    """Allow access only to users authorized to view the ticket object."""

    permission_denied_message = "You do not have permission to view this ticket."
    permission_denied_redirect = "ticket_list"

    def test_func(self):
        ticket = self.get_ticket_for_permission()
        return can_view_ticket(self.request.user, ticket)

    def get_ticket_for_permission(self):
        if hasattr(self, "get_object"):
            try:
                return self.get_object()
            except Exception:
                return None
        return None

