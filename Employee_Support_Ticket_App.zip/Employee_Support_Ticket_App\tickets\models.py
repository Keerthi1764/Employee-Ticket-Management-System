from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models


class Ticket(models.Model):
    class Category(models.TextChoices):
        HARDWARE = "Hardware", "Hardware"
        SOFTWARE = "Software", "Software"
        NETWORK = "Network", "Network"
        ACCESS = "Access", "Access"
        OTHER = "Other", "Other"

    class Priority(models.TextChoices):
        LOW = "Low", "Low"
        MEDIUM = "Medium", "Medium"
        HIGH = "High", "High"

    class Status(models.TextChoices):
        OPEN = "Open", "Open"
        IN_PROGRESS = "In Progress", "In Progress"
        RESOLVED = "Resolved", "Resolved"
        CLOSED = "Closed", "Closed"

    title = models.CharField(max_length=100)
    description = models.TextField()
    category = models.CharField(max_length=20, choices=Category.choices)
    priority = models.CharField(
        max_length=10, choices=Priority.choices, default=Priority.MEDIUM
    )
    status = models.CharField(
        max_length=20, choices=Status.choices, default=Status.OPEN
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="tickets",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at", "-id"]

    def __str__(self):
        return f"#{self.pk} - {self.title}" if self.pk else self.title

    @classmethod
    def get_selectable_statuses(cls, current_status):
        """Statuses support staff can set. Closed tickets are final."""
        if current_status == cls.Status.CLOSED:
            return []
        return [status for status, _label in cls.Status.choices if status != current_status]

    def clean(self):
        super().clean()
        errors = {}

        if self.title is not None and not str(self.title).strip():
            errors["title"] = "Title cannot be empty or contain only whitespace."
        if self.description is not None and not str(self.description).strip():
            errors["description"] = (
                "Description cannot be empty or contain only whitespace."
            )

        # Closed tickets are final and cannot be edited or reopened.
        if self.pk:
            previous = Ticket.objects.filter(pk=self.pk).first()
            if previous and previous.status == self.Status.CLOSED:
                changed = any(
                    getattr(self, field) != getattr(previous, field)
                    for field in ("title", "description", "category", "priority", "status")
                )
                if changed:
                    errors["status"] = "Closed tickets cannot be edited or reopened."

        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        if self.title is not None:
            self.title = self.title.strip()
        if self.description is not None:
            self.description = self.description.strip()
        self.full_clean()
        super().save(*args, **kwargs)


class Comment(models.Model):
    ticket = models.ForeignKey(
        Ticket, on_delete=models.CASCADE, related_name="comments"
    )
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="ticket_comments",
    )
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at", "id"]

    def __str__(self):
        ticket_id = self.ticket_id or "?"
        author = getattr(self.author, "username", "?")
        return f"Comment by {author} on ticket {ticket_id}"

    def clean(self):
        super().clean()
        errors = {}
        if self.text is not None and not str(self.text).strip():
            errors["text"] = "Comment text cannot be empty or contain only whitespace."
        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        if self.pk:
            raise ValidationError("Comments cannot be edited after submission.")
        if self.text is not None:
            self.text = self.text.strip()
        self.full_clean()
        super().save(*args, **kwargs)

