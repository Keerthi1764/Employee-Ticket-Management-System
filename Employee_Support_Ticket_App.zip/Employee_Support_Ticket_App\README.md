# Employee Support Ticket Management System

A role-based Django web application for employees to submit and track support tickets and for support staff to manage, update, and comment on tickets.

## Tech Stack
- Python 3.x
- Django 6.x
- SQLite (default Django database)
- Django built-in authentication
- Django templates with Bootstrap (CDN)

## Implemented Features
- **Authentication & roles (P2)**: Login/logout via Django auth, no public registration, role-based access using Django groups (`Employee`, `Support Staff`), server-side permission checks.
- **Ticket & comment data models (P3)**: `Ticket` and `Comment` models, admin registration, migrations, model/form validation.
- **Core ticket workflows (P4)**: Employees can create tickets, view their own tickets, and edit only their own tickets while the ticket is not `Closed`. Support staff can view all tickets and ticket details.
- **Status management & filtering (P5)**: Support staff can set any ticket status (`Open`, `In Progress`, `Resolved`, `Closed`). Closed tickets are final and cannot be edited or reopened. Support staff can filter tickets by status, category, and priority.
- **Comments (P6)**: Authorized users (ticket owner employee or support staff) can add comments, including on closed tickets. Comments are immutable, timestamped, shown in chronological order, and do not change ticket `updated_at`.
- **Sample data & tests (P7)**: Idempotent `seed` command, automated tests, and project documentation.

## Project Structure (key paths)
- `config/` - Django project settings and root URL configuration
- `tickets/` - Main application (models, views, forms, URLs, permissions, admin, tests, management commands, templates)
- `templates/` - Shared/base and auth templates
- `manage.py` - Django management entry point

## Setup & Run Instructions

### 1. Prerequisites
- Python 3 installed and available on PATH

### 2. Create and activate a virtual environment (Windows PowerShell)
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 3. Install dependencies
```powershell
pip install django
```

### 4. Apply migrations
```powershell
python manage.py migrate
```

### 5. (Optional but recommended) Create roles and sample data
This command is idempotent and can be run multiple times safely.
```powershell
python manage.py seed
```

`seed` will:
- ensure groups `Employee` and `Support Staff` exist
- create sample users `employee1`, `employee2` (Employee) and `support1` (Support Staff) if missing
- create the 5 required sample tickets if missing

**Passwords:**
- For newly created seed users, passwords are generated automatically and printed once by the command unless environment variables are provided.
- To control passwords during seeding, set environment variables before running `seed`:
  - `SEED_EMPLOYEE1_PASSWORD`
  - `SEED_EMPLOYEE2_PASSWORD`
  - `SEED_SUPPORT1_PASSWORD`

Example:
```powershell
$env:SEED_EMPLOYEE1_PASSWORD="ChangeMe123!"
$env:SEED_EMPLOYEE2_PASSWORD="ChangeMe123!"
$env:SEED_SUPPORT1_PASSWORD="ChangeMe123!"
python manage.py seed
```

> No real secrets or hardcoded production passwords are stored in source control.

### 6. (Optional) Create an admin/superuser
```powershell
python manage.py createsuperuser
```
Use the Django admin to provision/manage users and assign them to `Employee` or `Support Staff` groups as needed.

### 7. Run the development server
```powershell
python manage.py runserver
```
Open: http://127.0.0.1:8000/

## User Roles & Permissions
- **Employee**
  - Can log in and access employee dashboard/ticket views
  - Can create tickets
  - Can view only their own tickets
  - Can edit only their own tickets while the ticket is not `Closed` (title, description, category, priority)
  - Can comment on their own viewable tickets (including closed)
  - Cannot change ticket status, cannot access other users' tickets
- **Support Staff**
  - Can log in and access support dashboard/ticket views
  - Can view all tickets
  - Can filter tickets by status/category/priority
  - Can set a non-closed ticket to any status: `Open`, `In Progress`, `Resolved`, `Closed`
  - Can comment on any viewable ticket (including closed)
  - Cannot edit employee ticket fields
- **Closed tickets**: not editable, not reopenable, and their status cannot be changed; authorized users may still comment.
- **Comments**: non-empty/non-whitespace, shown in chronological order.

## Ticket Status Workflow
- Only Support Staff can change ticket status.
- Available statuses: `Open`, `In Progress`, `Resolved`, `Closed`.
- A non-closed ticket may be set to any other status.
- `Closed` is final: a closed ticket cannot be edited, reopened, or have its status changed.
- Status changes update ticket `updated_at`; adding comments does not.

## Sample Seed Data
When `python manage.py seed` is run:
- **Users**: `employee1`, `employee2` (Employee), `support1` (Support Staff)
- **Tickets**:
  - `Laptop not charging` (employee1, Hardware, High, Open)
  - `Need access to the shared project folder` (employee1, Access, Medium, Open)
  - `Request a second monitor` (employee1, Hardware, Low, Closed)
  - `Cannot log in to VPN` (employee2, Network, High, In Progress)
  - `Excel keeps crashing on startup` (employee2, Software, Medium, Resolved)

## Useful Management Commands
```powershell
python manage.py setup_roles   # ensure Employee/Support Staff groups exist (idempotent)
python manage.py seed          # setup roles + sample users + sample tickets (idempotent)
python manage.py makemigrations
python manage.py migrate
python manage.py check
python manage.py test
```

## Automated Tests
Run the full test suite:
```powershell
python manage.py test
```
Tests cover authentication/roles, ticket creation/list/detail/edit permissions and validation, status changes and filtering, comment authorization/validation/immutability/timestamp behavior, seed idempotency, and key unauthorized access protections.

## Known Limitations / Notes
- No public user registration; accounts and role assignments are admin-provisioned (by design per SRS).
- No ticket deletion and no comment edit/delete in the application UI (by design).
- UI uses Bootstrap via CDN; an internet connection may be required for CDN assets in the browser.
- Sample seed user passwords are generated at runtime when not supplied via environment variables and are printed to the console; store them securely if needed.

## Manual Verification Checklist (recommended)
- Log in as `employee1`/`employee2` and confirm only own tickets are visible/editable per rules.
- Log in as `support1` and confirm all tickets are visible, filters work, and any status can be selected for a non-closed ticket.
- Confirm closed tickets cannot be edited/reopened but can receive comments from authorized users.
- Confirm unauthenticated access redirects to login and direct-URL unauthorized actions are blocked.
- Run `python manage.py seed` twice to confirm idempotent behavior.
